## Activity 4.1 -- Cleaning Walmart data
